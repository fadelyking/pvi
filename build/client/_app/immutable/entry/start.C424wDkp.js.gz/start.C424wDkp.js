import{b as a}from"../chunks/entry.C9UphgoM.js";export{a as start};
