import{b as a}from"../chunks/entry.CfbvxF4Y.js";export{a as start};
